package uk.ac.bradford.cookgame;

import java.util.ArrayList;
import java.awt.Point;
import java.util.Random;
/**
 * The GameEngine class is responsible for managing information about the game,
 * creating levels, the player and customers, as well as updating information
 * when a key is pressed (processed by the InputHandler) while the game is
 * running.
 *
 * @author prtrundl
 */
public class GameEngine {

    /**
     * An enumeration type to represent different types of tiles that make up a
     * level. Each type has a corresponding image file that is used to draw the
     * correct tile to the screen for each tile in a level. FLOOR tiles are open
     * for movement for players and customers, WALL tiles should block movement
     * into that tile, FOOD tiles allow the player to pick up food, TABLE and
     * DOOR tiles can be used for both decoration and for implementing advanced
     * features.
     */
    public enum TileType {
        WALL, FLOOR1, FLOOR2, FOOD1, FOOD2, FOOD3, TABLE, DOOR;
    }

    /**
     * The width of the level, measured in tiles. Changing this may cause the
     * display to draw incorrectly, and as a minimum the size of the GUI would
     * need to be adjusted.
     */
    public static final int LEVEL_WIDTH = 35;

    /**
     * The height of the level, measured in tiles. Changing this may cause the
     * display to draw incorrectly, and as a minimum the size of the GUI would
     * need to be adjusted.
     */
    public static final int LEVEL_HEIGHT = 18;

    /**
     * A random number generator that can be used to include randomised choices
     * in the creation of levels, in choosing places to place the player and
     * customers, and to randomise movement etc. Passing an integer (e.g. 123)
     * to the constructor called here will give fixed results - the same numbers
     * will be generated every time WHICH CAN BE VERY USEFUL FOR TESTING AND
     * BUGFIXING!
     */
    private Random rng = new Random();

    /**
     * The current level number for the game. As the player completes levels the
     * level number should be increased and can be used to increase the
     * difficulty e.g. by creating additional customers and reducing patience
     * etc.
     */
    private int levelNumber = 1;  //current level

    /**
     * The current turn number. Increased by one every turn. Used to control
     * effects that only occur on certain turn numbers.
     */
    private int turnNumber = 0;

    /**
     * The current score in this game.
     */
    private int score = 0;

    /**
     * The GUI associated with this GameEngine object. This link allows the
     * engine to pass level and entity information to the GUI to be drawn.
     */
    private GameGUI gui;

    /**
     * The 2 dimensional array of tiles that represent the current level. The
     * size of this array should use the LEVEL_HEIGHT and LEVEL_WIDTH attributes
     * when it is created. This is the array that is used to draw images to the
     * screen by the GUI class.
     */
    private TileType[][] level;

    /**
     * An ArrayList of Point objects used to create and track possible locations
     * to place the player and customers when a new level is created.
     */
    private ArrayList<Point> spawnLocations;

    /**
     * A Player object that is the current player. This object stores the state
     * information for the player, including stamina and the current position
     * (which is a pair of co-ordinates that corresponds to a tile in the
     * current level - see the Entity class for more information on the
     * co-ordinate system used as well as the coursework specification
     * document).
     */
    private Player player;

    /**
     * An array of Customer objects that represents the customers in the current
     * level of the game. Elements in this array should be either an object of
     * the type Customer (meaning that a customer is exists (not fed/cleared
     * yet) and therefore needs to be drawn or moved) or should be null (which
     * means nothing is drawn or processed for movement). null values in this
     * array are skipped during drawing and movement processing. Customers that
     * the player correctly feeds can be replaced with (i.e. assigned) the value
     * null in this array which removes them from the game, using syntax such as
     * customers[i] = null.
     */
    private Customer[] customers;

    /**
     * Constructor that creates a GameEngine object and connects it with a
     * GameGUI object.
     *
     * @param gui The GameGUI object that this engine will pass information to
     * in order to draw levels and entities to the screen.
     */
    public GameEngine(GameGUI gui) {
        this.gui = gui;
    }

    /**
     * Generates a new level. The method builds a 2D array of TileType values
     * that will be used to draw level to the screen and to add a variety of
     * tiles into each level. Tiles can be floors, walls, tables, doors or food
     * sources.
     *
     * @return A 2D array filled with TileType values representing the level in
     * the current game. The size of this array should use the width and height
     * of the game level using the LEVEL_WIDTH and LEVEL_HEIGHT attributes.
     */
    private TileType[][] generateLevel() {
        // Creating new level
        TileType[][] level = new TileType[LEVEL_WIDTH][LEVEL_HEIGHT];
        // For loop to create level horizontally
        for (int i = 0; i < LEVEL_WIDTH; i++){
            // Inside the first loop, another loop to create level vertically
            for (int j = 0; j < LEVEL_HEIGHT; j++){
            // Defining the level
            level[i][j] = TileType.FLOOR1;
            /* Using if statement it checks how long LEVEL_HEIGHT is and takes 
             - 1 (tile) to build the wall vertically. */
            if (i == 0 || i == level.length -1){
                level[i][j] = TileType.WALL;
            }
            /* Using how long LEVEL_WIDTH is  value and taking -1 tile from the length 
            of LEVEL_WIDTH to build the wall horizontally.*/
            else if (j == 0 || j == level[i].length -1){
                level[i][j] = TileType.WALL;
            }
            }
        }
        // lets create maximum of 4 random walls inside the game
        // These walls can be vertical (0) or horizontal (1)
        // Loop for creating walls
        for (int w = 0; w < 4; w++) {
            // Lets get random number: 0 or 1
            int wallDirection = rng.nextInt(2);
            // if random number is 0, it will draw vertical wall
            if (wallDirection == 0) {
                // randomly creating the wall length (max 9 tile)
                int length = rng.nextInt(10);
                // randomly choosing the starting postion of the wall
                int wallX = rng.nextInt(LEVEL_WIDTH);
                int wallY = rng.nextInt(LEVEL_HEIGHT - rng.nextInt(8));
                /* checking if the wall is build inside the level_height, if it
                is true then will build the wall, otherwise it will subtract 
                the extra tiles and make the wall with remaining tiles.*/
                if (wallY + length > LEVEL_HEIGHT) {
                    wallY = LEVEL_HEIGHT - length;
                }
                /* Final loop which will make the wall after checking that if
                position of the wall ( x, y ) are on the floor1 .*/
                for (int i = 0; i < length; i++) {
                    if (level[wallX][wallY + i] == TileType.FLOOR1) {
                        level[wallX][wallY + i] = TileType.WALL;
                    }
                } 
            }
            // if random number is 1, it will draw horizontall wall
            if (wallDirection == 1) {
                // randomly creating the wall length (max 9 tile)
                int length2 = rng.nextInt(10);
                // randomly choosing the starting postion of the wall
                int wallX = rng.nextInt(LEVEL_WIDTH - rng.nextInt(8));
                int wallY = rng.nextInt(LEVEL_HEIGHT);
                /* checking if the wall is build inside the level_width, if it
                is true then will build the wall, otherwise it will subtract 
                the extra tiles and make the wall with remaining tiles.*/
                if (wallX + length2 > LEVEL_WIDTH) {
                    wallX = LEVEL_WIDTH - length2;
                }
                /* Final loop which will make the wall after checking that the
                position of the wall ( x, y ) are on the floor1 .*/
                for (int i = 0; i < length2; i++) {
                    if (level[wallX + i][wallY] == TileType.FLOOR1) {
                        level[wallX + i][wallY] = TileType.WALL;
                    }
                }
            }
        }
        // Creating Food1
        level [14][8] = TileType.FOOD1;
        
        // Creating Food2
        level [17][8] = TileType.FOOD2;
        
        // Creating Food3
        level [20][8] = TileType.FOOD3;
        
        // Creating tables
        level [29][4] = TileType.TABLE;
        level [5][4] = TileType.TABLE;
        level [5][14] = TileType.TABLE;
        level [29][14] = TileType.TABLE;
        
        // Creating Doors
        level [17][17] = TileType.DOOR;
        level [17][0] = TileType.DOOR;
        
        return level;// returns the 2D array that has been build in this method
    }

    /**
     * Generates spawn points for the player and customers. The method processes
     * the level array and finds positions that are suitable for spawning, i.e.
     * empty tiles such as floors. Suitable positions should then be added to
     * the ArrayList that can be retrieved as Point objects - Points are a
     * simple kind of object that contain an X and a Y co-ordinate stored using
     * the int primitive type.
     *
     * @return An ArrayList containing Point objects representing suitable X and
     * Y co-ordinates in the current level where the player or customers can be
     * added into the game.
     */
    private ArrayList<Point> getSpawns() {
        // Create a new array list
        ArrayList<Point> points = new ArrayList<>();
        /* Going through all the tiles and if the tile is not a TileType wall
         then add it to the array list */
           for (int i = 0; i < LEVEL_WIDTH; i++){
            for (int j = 0; j < LEVEL_HEIGHT; j++){
                TileType tile = level[i][j];
                if (tile != TileType.WALL)  {
                    points.add(new Point(i, j));
                }
            }
        }
        return points; // return the ArrayList
    }

    /**
     * Adds customers in suitable locations in the current level. The first
     * version of this method should picked fixed positions for customers by
     * calling the three argument version of the constructor for the Customer
     * class and using fixed values for the patience, X and Y positions of the
     * Customer to be added. Customer objects created this way should be added
     * into an array of Customer objects that is declared, instantiated and
     * filled inside this method. This array should the be returned by this
     * method. Customer objects in the array returned by this method will then
     * be drawn to the screen using the existing code in the GameGUI class.
     *
     * The second version of this method (described in a later task) should call
     * the four argument constructor for Customer (instead of the three argument
     * constructor) and pass an integer with a value of either 1, 2 or 3 for the
     * last argument. This will generate new types of customer that want
     * different types of food.
     *
     * The third version of this method should use the spawnLocations ArrayList
     * to pick suitable positions to add customers, removing these positions
     * from the spawns ArrayList as they are used (using the remove() method) to
     * avoid multiple customers spawning in the same location and to prevent
     * them from being added on top of walls, tables etc. The method then
     * creates customers by instantiating the Customer class, setting patience,
     * and then setting the X and Y position for the customer using the X and Y
     * values from the Point object that was removed from the spawns ArrayList.
     *
     * @return An array of Customer objects representing the customers for the
     * current level of the game
     */
    private Customer[] addCustomers() {
        // Creating 3 new customers object in the game
        Customer customers[] = new Customer[3];
        /* 3 index of customers with their maxpatience, fixed position and
        food type that thy will accept. (in brackets)*/
        
        // 1st and 2nd version of the code
        
        /*
        customers[0] = new Customer(100, 15, 6, 1);
        customers[1] = new Customer(100, 18, 10, 2);
        customers[2] = new Customer(100, 20, 6, 3);
        */
        
        /* 3rd Version of the code */
       
        
        // List of all possible spawn locations
        ArrayList<Point> points = getSpawns();
        // Get random point from spawn locations
        Point point = points.get(rng.nextInt(points.size() - 1));
        // Set customer to random location from spawn locations.
        customers[0] = new Customer(100, (int)point.getX(), (int)point.getY(), 1); 
        point = points.get(rng.nextInt(points.size() - 1));
        customers[1] = new Customer(100, (int)point.getX(), (int)point.getY(), 2);
        point = points.get(rng.nextInt(points.size() - 1));
        customers[2] = new Customer(100, (int)point.getX(), (int)point.getY(), 3);
        return customers; //return the created array of Customer objects
    }

    /**
     * Creates a Player object in the game. The method instantiates the Player
     * class and assigns values for the energy and position.
     *
     * The first version of this method should use fixed a fixed position for
     * the player to start, by setting fixed X and Y values when calling the
     * constructor in the Player class.
     *
     * The second version of this method should use the spawns ArrayList to
     * select a suitable location to spawn the player and removes the Point from
     * the spawns ArrayList. This will prevent the Player from being added to
     * the game inside a wall, bank or breach for example.
     *
     * @return A Player object representing the player in the game
     */
    private Player createPlayer() {
        // Creating new player object
             ArrayList<Point> points = getSpawns();
        // Get random point from spawn locations
        Point point = points.get(rng.nextInt(points.size() - 1));
        // Set player to the new spawn location.
        Player player = new Player (100, (int)point.getX(), (int)point.getY());
        
        
        return player; //return a Player object
        
    }

    /**
     * Handles the movement of the player when attempting to move in the game.
     * This method is automatically called by the InputHandler class when the
     * user has presses one of the arrow keys on the keyboard. The method should
     * check which direction for movement is required, by checking which
     * character was passed to this method (see parameter description below). If
     * the tile above, below, to the left or to the right is clear then the
     * player object should have its position changed to update its position in
     * the game window. If the target tile is not empty then the player should
     * not be moved, but other effects may happen such as giving a customer
     * food, or picking up food etc. To achieve this, the target tile should be
     * checked to determine the type of tile (food, table, wall etc.) and
     * appropriate methods called or attribute values changed.
     *
     * A second version of this method in a later task will also check if the
     * player's stamina is at zero, and if it is then the player should not be
     * moved.
     *
     * @param direction A char representing the direction that the player should
     * move. U is up, D is down, L is left and R is right.
     */
    public void movePlayer(char direction) {
        
        /* 1st version of the code ( Task 3)
        switch (direction) {
            case 'U':
                player.setPosition(player.getX(), player.getY() - 1);
                break;
            case 'D':
                player.setPosition(player.getX(), player.getY() + 1);
                break;
            case 'L':
                player.setPosition(player.getX() - 1, player.getY());
                break;
            case 'R':
                player.setPosition(player.getX() + 1, player.getY());
                break;
        }*/
        
        boolean moved = false;
        switch (direction) {
            case 'U':
                for (Customer customer : customers) {
                    if (customer != null) {
                        if (customer.getX() == player.getX() && customer.getY() == player.getY() - 1) {
                            deliverFood(customer);
                            moved = true;
                        }
                    }
                }   if (!moved) {
                    if (null == level[player.getX()][player.getY() - 1]) {
                        player.setPosition(player.getX(), player.getY() - 1);
                    } else switch (level[player.getX()][player.getY() - 1]) {
                        case FOOD1:
                            player.grabFood(1);
                            break;
                        case FOOD2:
                            player.grabFood(2);
                            break;
                        case FOOD3:
                            player.grabFood(3);
                            break;
                        case WALL:
                            break;
                        case TABLE:
                            break;
                        default:
                            player.setPosition(player.getX(), player.getY() - 1);
                            break;
                    }
                }   break;
            case 'D':
                for (Customer customer : customers) {
                    if (customer != null) {
                        if (customer.getX() == player.getX() && customer.getY() == player.getY() + 1) {
                            deliverFood(customer);
                            moved = true;
                        }
                    }
                }   if (!moved) {
                    if (null == level[player.getX()][player.getY() + 1]) {
                        player.setPosition(player.getX(), player.getY() + 1);
                    } else switch (level[player.getX()][player.getY() + 1]) {
                        case FOOD1:
                            player.grabFood(1);
                            break;
                        case FOOD2:
                            player.grabFood(2);
                            break;
                        case FOOD3:
                            player.grabFood(3);
                            break;
                        case WALL:
                            break;
                        case TABLE:
                            break;
                        default:
                            player.setPosition(player.getX(), player.getY() + 1);
                            break;
                    }
                }   break;
            case 'L':
                for (Customer customer : customers) {
                    if (customer != null) {
                        if (customer.getX() == player.getX() - 1 && customer.getY() == player.getY()) {
                            deliverFood(customer);
                            moved = true;
                        }
                    }
                }   if (!moved) {
                    if (null == level[player.getX() - 1][player.getY()]) {
                        player.setPosition(player.getX() - 1, player.getY());
                    } else switch (level[player.getX() - 1][player.getY()]) {
                        case FOOD1:
                            player.grabFood(1);
                            break;
                        case FOOD2:
                            player.grabFood(2);
                            break;
                        case FOOD3:
                            player.grabFood(3);
                            break;
                        case WALL:
                            break;
                        case TABLE:
                            break;
                        default:
                            player.setPosition(player.getX() - 1, player.getY());
                            break;
                    }
                }   break;
            case 'R':
                for (Customer customer : customers) {
                    if (customer != null) {
                        if (customer.getX() == player.getX() + 1 && customer.getY() == player.getY()) {
                            deliverFood(customer);
                            moved = true;
                        }
                    }
                }   if (!moved) {
                    if (null == level[player.getX() + 1][player.getY()]) {
                        player.setPosition(player.getX() + 1, player.getY());
                    } else switch (level[player.getX() + 1][player.getY()]) {
                        case FOOD1:
                            player.grabFood(1);
                            break;
                        case FOOD2:
                            player.grabFood(2);
                            break;
                        case FOOD3:
                            player.grabFood(3);
                            break;
                        case WALL:
                            break;
                        case TABLE:
                            break;
                        default:
                            player.setPosition(player.getX() + 1, player.getY());
                            break;
                    }
                }   break;
            default:
                break;
        }
        // Every player movement will redice stamina by -1
        player.changeStamina(-1);
        // Will remove fed customers 
        cleanFedCustomers();
        /* if player runs out of stamina, the game will restart and the score 
        will be set to 0. and it will display: "The game is over"*/
        if (player.getStamina() == 0){
            score = 0;
            startGame();
            System.out.println("The game is over!");
        }
        /* If all customer have been fed, it will start new level and will show
        the current level. Also will increase bring maxStamina for the player*/
        if (allCustomersFed() == true){
            nextLevel();
            System.out.println("Well done! Your are now at level: " + levelNumber );
            player.getMaxStamina();
        }
    }
        

    /**
     * Attempts to give a customer the food that the player is carrying. This
     * method should only be called (from the movePlayer method) when the player
     * attempts to move into the same tile as a customer and the player is
     * already carrying the right type of food - i.e. the type of food that the
     * customer wants.
     *
     * This method should call a method on the player object to give the food
     * (thus setting the player's attributes properly to reflect that they
     * delivered food and now can pick up more), and increase the score as well
     * as printing the score to the standard output. Finally it should "feed"
     * the customer by calling the correct method on the Customer object
     * indicating that the player has "fed".
     *
     * @param g The Customer object corresponding to the customer in the game
     * that the player just attempted to move into the same tile as.
     */
    private void deliverFood(Customer c) {
        /* If player has food and reaches the customer. then he gonna check 
        what kind of cutomer he has in front of and what kind of food he wants
        if the player has the right food he will deliver the food */
        if (player.getCarriedFoodType() == c.getFoodWanted()){
            player.giveFood();
            c.feed();
            /* Getting remaining patient from customers and convert into
            player stamina */
            player.changeStamina(player.getStamina() + c.getPatience());
            /* Score of the player, and this will increase 
            everytimes he feeds the customer*/
            score = score + c.getPatience();
            System.out.println("Your score is: " + score);
        }
    }

    /**
     * Moves a specific customer in the game. The method updates the X and Y
     * attributes of the Customer object passed to the method, to set its new
     * position.
     *
     * @param c The Customer that needs to be moved
     */
    private void moveCustomer(Customer c) {
        // Getting current customer position X and Y
        int x = c.getX();
        int y = c.getY();
        // By using switch cases getting randon number between 0 to 4
        switch(rng.nextInt(4)) {
            // Move right
                case 0: {
                    x = x + 1;
                    break;
                }
                // Move down
                case 1: {
                    y = y + 1;
                    break;
                }
                // Move left
                case 2: {
                    x = x - 1;
                    break;
                }
                // Move up
                case 3: {
                    y = y - 1;
                    break;
                }
        }
        // Prevent customer to moving into those tiles
        TileType tile = level[x][y];
        switch (tile) {
            case WALL:    
            case FOOD1:
            case FOOD2:
            case FOOD3:
            case TABLE:{
                return;
            }
        }
        // list all customers
        for (Customer c2 : customers) {
            /*If customer doesn't exist or is the same then stop the code and 
            prevent the customer from moving into the another customer*/
            if (c2 == null || c2 == c) continue;
            if (c2.getX() == x && c2.getY() == y) {
                return;
            }
        }
        // Setting customers random position
        c.setPosition(x, y);
        
    }
    
        /**
     * Moves all customers on the current level. This method iterates over all
     * elements of the customers array (e.g. using a for loop) and checks if
     * each one is null (using an if statement inside that for loop). For every
     * element of the array that is NOT null, this method calls the moveCustomer
     * method and passes it the current array element (i.e. the current customer
     * object being used in the loop).
     */
    private void moveAllCustomers() {
        //Loop for the customers
        for (Customer c: customers){
            // Checking if the customer still exists, move them.
            if (c != null) {
                moveCustomer(c);  
            }
        }
    }

    /**
     * Processes the customers array to find any Customer in the array that has
     * been fed (i.e. given food by the player of the type they wanted). Any
     * Customer in the array with a "fed" attribute value of true should be set
     * to null; when drawing or moving customers the null elements in the
     * customers array are skipped, essentially removing them from the game.
     */
    private void cleanFedCustomers() {
        // Declare the variable index
        int index = 0;
        // Loop through all the cusotmers
        for (Customer customer : customers) {
            // Check if customer in still there.
            if (customer != null) {
                // Check if the customer has been fed then remove the customer
                if (customer.beenFed()) {
                    customers[index] = null;    
                }
            }
            index ++;
        }
    }

    /**
     * This method is called when the number of "unfed" customers in the level
     * is zero, meaning that the player has fed all customers, "completing" the
     * level. This method is similar to the startGame method and will use SOME
     * identical code.
     *
     * This method should increase the current level number, create a new level
     * by calling the generateLevel method and setting the level attribute using
     * the returned 2D array, add new Customers, and finally place the player in
     * the new level.
     *
     * A second version of this method in a later task should also find suitable
     * positions to add customers and the player using the spawnLocations
     * ArrayList and code in the getSpawns method.
     */
    private void nextLevel() {
        /* need to add level counter and everytime the player feed all customers,
        new round will start
        */
        levelNumber = levelNumber + 1;
        /* Calling the generate level and settings, to build new level again but
        this time modifying player into placePlayer method. */
        level = generateLevel();
        spawnLocations = getSpawns();
        customers = addCustomers();
        placePlayer();
        
    }

    /**
     * The first version of this method should place the player in the game
     * level by setting new fixed X and Y values for the player object in this
     * class.
     *
     * The second version of this method in a later task should place the player
     * in a game level by choosing a position from the spawnLocations ArrayList,
     * removing the spawn position as it is used. The method sets the players
     * position in the level by calling its setPosition method with the x and y
     * values of the Point taken from the spawnLocations ArrayList.
     */
    private void placePlayer() {
        // List of all possible spawn locations
        ArrayList<Point> points = getSpawns();
        // Get random point from spawn locations
        Point point = points.get(rng.nextInt(points.size() - 1));
        // Set player to the new spawn location.
        player.setPosition((int)point.getX(), (int)point.getY());
        player.changeStamina(100);
    }

    /**
     * This method should be called each game turn and should check if all
     * NON-NULL Customer objects in the customers array have been fed. If all
     * valid Customer objects have been fed or the array contains only null
     * values then this method should return true, but if there are any customer
     * objects in the array with a "fed" attribute value of false then the
     * method should return false.
     *
     * @return true if all Customer objects in the customers array have been
     * fed, false otherwise
     */
    private boolean allCustomersFed() {
        // Loop for the customer 
        for (Customer c : customers) {
            /* Check if there is any customer left and if he has not been fed
            then reutrn false*/
            if (c != null && !c.beenFed()) return false;
        }
        // If customer fed return true.
        return true;   //modify to return either true or false
    }

    /**
     * This method is automatically called by doTurn, and it should reduce the
     * patience value for all Customer objects in the customers array by a small
     * fixed amount, by using a for loop that iterates over the customers array,
     * checking for non-null elements and calling an appropriate method on any
     * non-null objects in the array.
     */
    private void reduceCustomerPatience() {
        //For loop that will go through all the customers
        for (Customer customer : customers) {
            /* Will check if there is still any customer and then reduce the
            customer patient */
            if (customer != null) {
                customer.changePatience(-1);
            }
        }
    }

    /**
     * Performs a single turn of the game when the user presses a key on the
     * keyboard. The method clears (removes from the game) "fed" customers every
     * ten turns, moves any customers that have not been fed and cleared every
     * three turns, and increments the turn number. Finally it makes the GUI
     * redraw the game level by passing it the level, player and customers
     * objects for the current level.
     *
     * A second version of this method in a later task will also check if all
     * customers in the current level have been fed, and if they have it will
     * call the nextLevel() method to generate a new, harder level.
     *
     * A third version of this method will also increase the player's stamina
     * slightly to allow them to recover and move again if their stamina runs
     * out.
     */
    public void doTurn() {
        turnNumber++;
        if (turnNumber % 10 == 0) {
            cleanFedCustomers();
        }
        if (turnNumber % 3 == 0) {
            moveAllCustomers();
            reduceCustomerPatience();
        }
        gui.updateDisplay(level, player, customers);
    }

    /**
     * Starts a game. This method generates a level, finds spawn positions in
     * the level, adds customers and the player and then requests the GUI to
     * update the level on screen using the information on level, player and
     * customers.
     */
    public void startGame() {
        level = generateLevel();
        spawnLocations = getSpawns();
        customers = addCustomers();
        player = createPlayer();
        gui.updateDisplay(level, player, customers);
    }
}
